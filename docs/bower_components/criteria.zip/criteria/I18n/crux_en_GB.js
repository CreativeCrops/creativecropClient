_cruxUtils._cruxLocale = {
	"crm.security.group.users.empty": "No Users Found", //NO I18n
	"crm.label.picklist.none": "--None--", //NO I18n
	"crm.label.selected" : "Selected",//NO I18n
	"AM" : "AM",//NO I18n
	"Call" : "Call",//NO I18n
	"crm.button.cancel" : "Cancel",//NO I18n
	"crm.button.save" : "Save",//NO I18n
	"crm.zti.label.user": "User Name", //NO I18n\
	"crm.usrpop.non.selected" : "Selected Users",//No I18n
	"crm.globalsearch.search.title" : "Search",//No I18n
	"None" : "None",//No I18n
	"crm.label.criteria.pattern" : "Criteria Pattern",//No I18n
	"Search Users": "Search Users", //NO I18n
	"and" : "and", //No I18n
	"or" : "or", //No I18n
	"crm.label.or" : "OR", //No I18n
	"crm.label.and" : "AND", //No I18n
	"crm.field.valid.check" : "Please enter a valid {0}", //No I18n
	"is" : "is",//No I18n
	"isn\'t" : "isn't",//No I18n
	"contains" : "contains",//No I18n
	"doesn\'t contain" : "doesn't contain",//No I18n
	"starts with" : "starts with",//No I18n
	"ends with" : "ends with",//No I18n
	"is empty" : "is empty",//No I18n
	"is not empty" : "is not empty",//No I18n
	"is before" : "",//No I18n
	"is after" : "",//No I18n
	"between" : "",//No I18n
	"not between" : "",//No I18n
	"Today" : "",//No I18n
	"Tommorow" : "",//No I18n
	"Tommorow Onwards" : "",//No I18n
	"Yesterday" : "",//No I18n
	"Till Yesterday" : "",//No I18n
	"Last Month" : ""//No I18n
}
