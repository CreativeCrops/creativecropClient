_cruxUtils._cruxLocale = {
	"crm.security.group.users.empty": "Nebyli nalezeni \u017e\u00e1dn\u00ed u\u017eivatel\u00e9.", //NO I18n
	"crm.label.picklist.none": "Nic", //NO I18n
	"crm.label.selected" : "Vybr\u00e1no",//NO I18n
	"crm.label.notSelected" : "Nevybr\u00e1no",//NO I18n
	"AM" : "Dopo",//NO I18n
	"Call" : "Hovor",//NO I18n
	"crm.phoneNo.Link.Title" : "Vol\u00e1n\u00ed p\u0159es Skype",//NO I18n
	"crm.button.cancel" : "Zru\u0161it",//NO I18n
	"crm.button.save" : "crm.button.save=Ulo\u017eit",//NO I18n
	"crm.no.data.found" : "\u017d\u00e1dn\u00fd nalezen\u00fd \u00fadaj",//NO I18n
	"crm.usrpop.non.selected" : "Vybran\u00ed u\u017eivatel\u00e9",//NO I18n
	"crm.zti.label.user": "U\u017eivatelsk\u00e9 jm\u00e9no", //NO I18n
	"crm.label.no.options.found" : "Nebyly nalezeny \u017e\u00e1dn\u00e9 mo\u017enosti",//No I18n
	"crm.globalsearch.search.title" : "Vyhledat",//No I18n
	"None" : "Nic",//No I18n
	"crm.label.criteria.pattern" : "Vzor krit\u00e9ria",//No I18n
	"crm.label.edit.criteria.pattern" : "Upravit vzor",//No I18n
	"criteria.error.alert.brackets.count.mismatch" : "Z\u00e1vorky vzoru se neshoduj\u00ed.",//No I18n
	"criteria.error.alert.brackets.invalid" : "Neplatn\u00e9 z\u00e1vorky okolo oper\u00e1toru podm\u00ednky.",//No I18n
	"crm.criteria.number.notmatch.check" : "Zkontrolujte vzor na {0}.",//No I18n
	"criteria.error.alert.other.params" : "Neplatn\u00fd obsah tohoto vzoru.", //No I18n
	"crm.label.search.for.users": "Vyhledat u\u017eivatele", //NO I18n
	"criteria.error.alert.andor.rowcount.mismatch" : "Vzor krit\u00e9ri\u00ed se neshoduje s vybran\u00fdmi podm\u00ednkami.", //No I18n
	"criteria.error.alert.critnum.rowcount.mismatch" : "Vzor krit\u00e9ri\u00ed se neshoduje s vybran\u00fdmi podm\u00ednkami.", //No I18n
	"and" : "a", //No I18n
	"or" : "nebo", //No I18n
	"crm.label.or" : "NEBO", //No I18n
	"crm.label.and" : "A", //No I18n
	"crm.criteria.fieldlabel.valid.check" : "Zadejte platn\u00fd \u0161t\u00edtek pro \u0159\u00e1dek {0}.", //No I18n
	"crm.criteria.condition.valid.check" : "Zadejte platn\u00e9 podm\u00ednky pro {0}.", //No I18n
	"crm.field.valid.check" : "Zadejte platn\u00fd {0}.", //No I18n
	"crm.alert.label.savepattern" : "Ulo\u017ete vzor p\u0159ed zm\u011bnou krit\u00e9ri\u00ed.",//No I18n
	"crm.criteria.max.rowcnt.exceeds" : "Nem\u016f\u017eete p\u0159idat dal\u0161\u00ed krit\u00e9ria.",//No I18n
	"is" : "je",//No I18n
	"isn\'t" : "nen\u00ed",//No I18n
	"contains" : "obsahuje",//No I18n
	"doesn\'t contain" : "neobsahuje",//No I18n
	"starts with" : "za\u010d\u00edn\u00e1 na",//No I18n
	"ends with" : "kon\u010d\u00ed na",//No I18n
	"is empty" : "je pr\u00e1zdn\u00e9",//No I18n
	"is not empty" : "nen\u00ed pr\u00e1zdn\u00e9",//No I18n
	"is before" : "",//No I18n
	"is after" : "",//No I18n
	"between" : "",//No I18n
	"not between" : "",//No I18n
	"Today" : "",//No I18n
	"Tommorow" : "",//No I18n
	"Tommorow Onwards" : "",//No I18n
	"Yesterday" : "",//No I18n
	"Till Yesterday" : "",//No I18n
	"Last Month" : ""//No I18n
}
