_cruxUtils._cruxLocale = {
	"crm.security.group.users.empty": "\u05dc\u05d0 \u05e0\u05de\u05e6\u05d0\u05d5 \u05de\u05e9\u05ea\u05de\u05e9\u05d9\u05dd.", //NO I18n
	"crm.label.picklist.none": "\u05d0\u05d9\u05df", //NO I18n
	"crm.usrpop.non.selected" : "\u05de\u05e9\u05ea\u05de\u05e9\u05d9\u05dd \u05e9\u05e0\u05d1\u05d7\u05e8\u05d5",//NO I18n
	"crm.label.selected" : "\u05e0\u05d1\u05d7\u05e8",//NO I18n
	"crm.label.notSelected" : "\u05dc\u05d0 \u05e0\u05d1\u05d7\u05e8",//NO I18n
	"AM" : "\u05d1\u05d5\u05e7\u05e8",//NO I18n
	"Call" : "\u05e9\u05d9\u05d7\u05ea \u05d8\u05dc\u05e4\u05d5\u05df",//NO I18n
	"crm.phoneNo.Link.Title" : "\u05d4\u05ea\u05e7\u05e9\u05e8 \u05d1\u05d0\u05de\u05e6\u05e2\u05d5\u05ea Skype",//NO I18n
	"crm.button.cancel" : "\u05d1\u05d9\u05d8\u05d5\u05dc",//NO I18n
	"crm.button.save" : "\u05e9\u05de\u05d9\u05e8\u05d4",//NO I18n
	"crm.no.data.found" : "\u05dc\u05d0 \u05e0\u05de\u05e6\u05d0 \u05de\u05d9\u05d3\u05e2.",//NO I18n
	"crm.zti.label.user": "\u05e9\u05dd \u05de\u05e9\u05ea\u05de\u05e9", //NO I18n
	"crm.label.no.options.found" : "\u05dc\u05d0 \u05e0\u05de\u05e6\u05d0\u05d5 \u05d0\u05e4\u05e9\u05e8\u05d5\u05d9\u05d5\u05ea.",//No I18n
	"crm.globalsearch.search.title" : "\u05d7\u05e4\u05e9",//No I18n
	"None" : "\u05db\u05dc\u05d5\u05dd",//No I18n
	"crm.label.criteria.pattern" : "\u05ea\u05d1\u05e0\u05d9\u05ea \u05e7\u05e8\u05d9\u05d8\u05e8\u05d9\u05d5\u05e0\u05d9\u05dd",//No I18n
	"crm.label.edit.criteria.pattern" : "\u05e2\u05e8\u05d9\u05db\u05ea \u05ea\u05d1\u05e0\u05d9\u05ea",//No I18n
	"criteria.error.alert.brackets.count.mismatch" : "\u05d4\u05e1\u05d5\u05d2\u05e8\u05d9\u05d9\u05dd \u05d4\u05de\u05e8\u05d5\u05d1\u05e2\u05d9\u05dd \u05e9\u05dc \u05d4\u05ea\u05d1\u05e0\u05d9\u05ea \u05dc\u05d0 \u05de\u05ea\u05d0\u05d9\u05de\u05d9\u05dd.",//No I18n
	"criteria.error.alert.brackets.invalid" : "\u05de\u05d9\u05e8\u05db\u05d0\u05d5\u05ea \u05dc\u05d0 \u05d7\u05d5\u05e7\u05d9\u05d5\u05ea \u05e1\u05d1\u05d9\u05d1 \u05d0\u05d5\u05e4\u05e8\u05d8\u05d5\u05e8(\u05d9\u05dd) \u05ea\u05e0\u05d0\u05d9.",//No I18n
	"crm.criteria.number.notmatch.check" : "\u05d0\u05e0\u05d0 \u05d1\u05d3\u05d5\u05e7 \u05d0\u05ea \u05d4\u05ea\u05d1\u05e0\u05d9\u05ea \u05d1{0}.",//No I18n
	"criteria.error.alert.other.params" : "\u05ea\u05d5\u05db\u05df \u05dc\u05d0 \u05d7\u05d5\u05e7\u05d9 \u05d1\u05ea\u05d1\u05e0\u05d9\u05ea \u05d6\u05d0\u05ea.", //No I18n
	"crm.label.search.for.users": "\u05d7\u05e4\u05e9 \u05de\u05e9\u05ea\u05de\u05e9\u05d9\u05dd", //NO I18n
	"criteria.error.alert.andor.rowcount.mismatch" : "\u05ea\u05d1\u05e0\u05d9\u05ea \u05d4\u05e7\u05e8\u05d9\u05d8\u05e8\u05d9\u05d5\u05e0\u05d9\u05dd \u05dc\u05d0 \u05ea\u05d5\u05d0\u05de\u05ea \u05dc\u05ea\u05e0\u05d0\u05d9\u05dd \u05e9\u05d1\u05d7\u05e8\u05ea.", //No I18n
	"criteria.error.alert.critnum.rowcount.mismatch" : "\u05ea\u05d1\u05e0\u05d9\u05ea \u05d4\u05e7\u05e8\u05d9\u05d8\u05e8\u05d9\u05d5\u05e0\u05d9\u05dd \u05dc\u05d0 \u05ea\u05d5\u05d0\u05de\u05ea \u05dc\u05ea\u05e0\u05d0\u05d9\u05dd \u05e9\u05d1\u05d7\u05e8\u05ea.", //No I18n
	"and" : "\u05d5", //No I18n
	"or" : "\u05d0\u05d5", //No I18n
	"crm.label.or" : "\u05d0\u05d5", //No I18n
	"crm.label.and" : "\u05d5", //No I18n
	"crm.criteria.fieldlabel.valid.check" : "\u05d0\u05e0\u05d0 \u05d4\u05db\u05e0\u05e1 \u05ea\u05d5\u05d5\u05d9\u05ea \u05e9\u05d3\u05d4 \u05d7\u05d5\u05e7\u05d9\u05ea \u05d1\u05e9\u05d5\u05e8\u05d4 {0}.", //No I18n
	"crm.criteria.condition.valid.check" : "\u05d0\u05e0\u05d0 \u05e6\u05d9\u05d9\u05df \u05ea\u05e0\u05d0\u05d9 \u05d7\u05d5\u05e7\u05d9 \u05e2\u05d1\u05d5\u05e8 {0}.", //No I18n
	"crm.field.valid.check" : "\u05d0\u05e0\u05d0 \u05d4\u05d6\u05df {0} \u05d7\u05d5\u05e7\u05d9.", //No I18n
	"crm.alert.label.savepattern" : "\u05e9\u05de\u05d5\u05e8 \u05d0\u05ea \u05d4\u05ea\u05d1\u05e0\u05d9\u05ea \u05dc\u05e4\u05e0\u05d9 \u05e9\u05d9\u05e0\u05d5\u05d9 \u05d4\u05e7\u05e8\u05d9\u05d8\u05e8\u05d9\u05d5\u05e0\u05d9\u05dd.",//No I18n
	"crm.criteria.max.rowcnt.exceeds" : "\u05dc\u05d0 \u05e0\u05d9\u05ea\u05df \u05dc\u05d4\u05d5\u05e1\u05d9\u05e3 \u05e7\u05e8\u05d9\u05d8\u05e8\u05d9\u05d5\u05e0\u05d9\u05dd \u05e0\u05d5\u05e1\u05e4\u05d9\u05dd.",//No I18n
	"is" : "\u05e0\u05de\u05e6\u05d0",//No I18n
	"isn\'t" : "\u05dc\u05d0 \u05e0\u05de\u05e6\u05d0",//No I18n
	"contains" : "\u05de\u05db\u05d9\u05dc",//No I18n
	"doesn\'t contain" : "\u05dc\u05d0 \u05de\u05db\u05d9\u05dc",//No I18n
	"starts with" : "\u05de\u05ea\u05d7\u05d9\u05dc \u05d1",//No I18n
	"ends with" : "\u05e0\u05d2\u05de\u05e8 \u05d1",//No I18n
	"is empty" : "\u05e8\u05d9\u05e7",//No I18n
	"is not empty" : "\u05d0\u05d9\u05e0\u05d5 \u05e8\u05d9\u05e7",//No I18n
	"is before" : "",//No I18n
	"is after" : "",//No I18n
	"between" : "",//No I18n
	"not between" : "",//No I18n
	"Today" : "",//No I18n
	"Tommorow" : "",//No I18n
	"Tommorow Onwards" : "",//No I18n
	"Yesterday" : "",//No I18n
	"Till Yesterday" : "",//No I18n
	"Last Month" : ""//No I18n
}
