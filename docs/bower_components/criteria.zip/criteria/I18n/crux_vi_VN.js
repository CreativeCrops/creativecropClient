_cruxUtils._cruxLocale = {
	"crm.security.group.users.empty": "Kh\u00f4ng t\u00ecm th\u1ea5y ng\u01b0\u1eddi d\u00f9ng n\u00e0o.", //NO I18n
	"crm.label.picklist.none": "Kh\u00f4ng c\u00f3", //NO I18n
	"crm.usrpop.non.selected" : "Nh\u1eefng Ng\u01b0\u1eddi D\u00f9ng \u0110\u00e3 Ch\u1ecdn",//NO I18n
	"crm.zti.label.user": "T\u00ean ng\u01b0\u1eddi d\u00f9ng", //NO I18n
	"crm.label.selected" : "\u0110\u01b0\u1ee3c ch\u1ecdn",//NO I18n
	"crm.label.notSelected" : "Ch\u01b0a Ch\u1ecdn",//NO I18n
	"AM" : "S\u00c1",//NO I18n
	"Call" : "Cu\u1ed9c g\u1ecdi",//NO I18n
	"crm.phoneNo.Link.Title" : "G\u1ecdi b\u1eb1ng Skype",//NO I18n
	"crm.button.cancel" : "Hu\u0309y bo\u0309",//NO I18n
	"crm.button.save" : "L\u01b0u",//NO I18n
	"crm.no.data.found" : "Kh\u00f4ng t\u00ecm th\u1ea5y d\u1eef li\u1ec7u.",//NO I18n
	"crm.label.no.options.found" : "Kh\u00f4ng t\u00ecm th\u1ea5y t\u00f9y ch\u1ecdn.",//No I18n
	"crm.globalsearch.search.title" : "T\u00ecm ki\u1ebfm",//No I18n
	"None" : "Kh\u00f4ng",//No I18n
	"crm.label.criteria.pattern" : "M\u1eabu Ti\u00eau ch\u00ed quan tr\u1ecdng",//No I18n
	"crm.label.edit.criteria.pattern" : "S\u1eeda M\u00f4 Th\u1ee9c",//No I18n
	"criteria.error.alert.brackets.count.mismatch" : "C\u00e1c ngo\u1eb7c m\u00f4 th\u1ee9c kh\u00f4ng kh\u1edbp.",//No I18n
	"criteria.error.alert.brackets.invalid" : "D\u1ea5u ngo\u1eb7c kh\u00f4ng h\u1ee3p l\u1ec7 quanh (c\u00e1c) to\u00e1n t\u1eed \u0111i\u1ec1u ki\u1ec7n.",//No I18n
	"crm.criteria.number.notmatch.check" : "Vui l\u00f2ng ki\u1ec3m tra m\u00f4 th\u1ee9c t\u1ea1i {0}.",//No I18n
	"criteria.error.alert.other.params" : "N\u1ed9i dung kh\u00f4ng h\u1ee3p l\u1ec7 trong m\u00f4 th\u1ee9c n\u00e0y.", //No I18n
	"crm.label.search.for.users": "T\u00ecm Ki\u1ebfm Ng\u01b0\u1eddi D\u00f9ng", //NO I18n
	"criteria.error.alert.andor.rowcount.mismatch" : "M\u00f4 Th\u1ee9c Ti\u00eau Ch\u00ed kh\u00f4ng kh\u1edbp v\u1edbi c\u00e1c \u0111i\u1ec1u ki\u1ec7n b\u1ea1n ch\u1ecdn.", //No I18n
	"criteria.error.alert.critnum.rowcount.mismatch" : "M\u00f4 Th\u1ee9c Ti\u00eau Ch\u00ed kh\u00f4ng kh\u1edbp v\u1edbi c\u00e1c \u0111i\u1ec1u ki\u1ec7n b\u1ea1n ch\u1ecdn.", //No I18n
	"and" : "v\u00e0", //No I18n
	"or" : "ho\u1eb7c", //No I18n
	"crm.label.or" : "Ho\u1eb7c", //No I18n
	"crm.label.and" : "V\u00e0", //No I18n
	"crm.criteria.fieldlabel.valid.check" : "Vui l\u00f2ng nh\u1eadp nh\u00e3n tr\u01b0\u1eddng h\u1ee3p l\u1ec7 v\u00e0o h\u00e0ng {0}.", //No I18n
	"crm.criteria.condition.valid.check" : "Vui l\u00f2ng cho bi\u1ebft m\u1ed9t \u0111i\u1ec1u ki\u1ec7n h\u1ee3p l\u1ec7 cho {0}.", //No I18n
	"crm.field.valid.check" : "Vui l\u00f2ng nh\u1eadp m\u1ed9t {0} h\u1ee3p l\u1ec7.", //No I18n
	"crm.custom.field.less.than.to" : "Ph\u1ea1m vi <i>T\u1eeb</i> kh\u00f4ng \u0111\u01b0\u1ee3c l\u1edbn h\u01a1n ph\u1ea1m vi <i>\u0110\u1ebfn</i>." , //No I18n
	"crm.alert.label.savepattern" : "L\u01b0u m\u00f4 th\u1ee9c tr\u01b0\u1edbc khi thay \u0111\u1ed5i c\u00e1c ti\u00eau ch\u00ed.",//No I18n
	"crm.criteria.max.rowcnt.exceeds" : "B\u1ea1n kh\u00f4ng th\u1ec3 th\u00eam c\u00e1c ti\u00eau ch\u00ed kh\u00e1c.",//No I18n
	"is" : "l\u00e0",//No I18n
	"isn\'t" : "kh\u00f4ng l\u00e0",//No I18n
	"contains" : "ch\u1ee9a \u0111\u1ef1ng",//No I18n
	"doesn\'t contain" : "kh\u00f4ng ch\u1ee9a",//No I18n
	"starts with" : "b\u1eaft \u0111\u1ea7u v\u1edbi",//No I18n
	"ends with" : "k\u1ebft th\u00fac v\u1edbi",//No I18n
	"is empty" : "c\u00f2n tr\u1ed1ng",//No I18n
	"is not empty" : "kh\u00f4ng tr\u1ed1ng"//No I18n
}
