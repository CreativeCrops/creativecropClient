_cruxUtils._cruxLocale = {
	"crm.security.group.users.empty": "Kullan\u0131c\u0131 bulunamad\u0131.", //NO I18n
	"crm.label.picklist.none": "Bulunamad\u0131", //NO I18n
	"crm.usrpop.non.selected" : "Se\u00e7ili Kullan\u0131c\u0131lar",//NO I18n
	"crm.zti.label.user": "Kullan\u0131c\u0131 Ad\u0131", //NO I18n
	"crm.label.selected" : "Se\u00e7ili",//NO I18n
	"crm.label.notSelected" : "Se\u00e7ilmedi",//NO I18n
	"AM" : "\u00d6\u00d6",//NO I18n
	"Call" : "Arama",//NO I18n
	"crm.phoneNo.Link.Title" : "Skype ile arama",//NO I18n
	"crm.button.cancel" : "\u0130ptal",//NO I18n
	"crm.button.save" : "Kaydet",//NO I18n
	"crm.no.data.found" : "Veri bulunamad\u0131.",//NO I18n
	"crm.label.no.options.found" : "Hi\u00e7bir se\u00e7enek bulunamad\u0131.",//No I18n
	"crm.globalsearch.search.title" : "Ara",//No I18n
	"None" : "Se\u00e7iniz",//No I18n
	"crm.label.criteria.pattern" : "Kriter D\u00fczeni",//No I18n
	"crm.label.edit.criteria.pattern" : "Desen D\u00fczenle",//No I18n
	"criteria.error.alert.brackets.count.mismatch" : "D\u00fczen k\u00f6\u015feli ayra\u00e7lar\u0131 e\u015fle\u015fmiyor.",//No I18n
	"criteria.error.alert.brackets.invalid" : "Ko\u015ful i\u015flecinin/i\u015fle\u00e7lerinin yanlar\u0131ndaki k\u00f6\u015feli parantezler ge\u00e7ersiz.",//No I18n
	"crm.criteria.number.notmatch.check" : "L\u00fctfen {0}\u2019deki d\u00fczeni kontrol edin.",//No I18n
	"criteria.error.alert.other.params" : "Bu d\u00fczende ge\u00e7ersiz i\u00e7erik var.", //No I18n
	"crm.label.search.for.users": "Kullan\u0131c\u0131lar\u0131 Ara", //NO I18n
	"criteria.error.alert.andor.rowcount.mismatch" : "\u00d6l\u00e7\u00fct D\u00fczeni, se\u00e7ti\u011finiz ko\u015fullar ile e\u015fle\u015fmiyor.", //No I18n
	"criteria.error.alert.critnum.rowcount.mismatch" : "\u00d6l\u00e7\u00fct D\u00fczeni, se\u00e7ti\u011finiz ko\u015fullar ile e\u015fle\u015fmiyor.", //No I18n
	"and" : "ve", //No I18n
	"or" : "veya", //No I18n
	"crm.label.or" : "VEYA", //No I18n
	"crm.label.and" : "VE", //No I18n
	"crm.criteria.fieldlabel.valid.check" : "L\u00fctfen {0} sat\u0131r\u0131na ge\u00e7erli bir alan etiketi girin.", //No I18n
	"crm.criteria.condition.valid.check" : "L\u00fctfen {0} i\u00e7in ge\u00e7erli bir ko\u015ful belirtin.", //No I18n
	"crm.field.valid.check" : "L\u00fctfen ge\u00e7erli bir {0} girin.", //No I18n
	"crm.custom.field.less.than.to" : "<i>Biti\u015f </i> aral\u0131\u011f\u0131 <i>Ba\u015flang\u0131\u00e7</i> aral\u0131\u011f\u0131ndan b\u00fcy\u00fck olamaz.", //No I18n
	"crm.alert.label.savepattern" : "\u00d6l\u00e7\u00fctleri de\u011fi\u015ftirmeden \u00f6nce d\u00fczeni kaydedin.",//No I18n
	"crm.criteria.max.rowcnt.exceeds" : "Daha fazla \u00f6l\u00e7\u00fct ekleyemezsiniz.",//No I18n
	"is" : "e\u015fit",//No I18n
	"isn\'t" : "e\u015fit de\u011fil",//No I18n
	"contains" : "i\u00e7erir",//No I18n
	"doesn\'t contain" : "i\u00e7ermez",//No I18n
	"starts with" : "ile ba\u015flar",//No I18n
	"ends with" : "ile biter",//No I18n
	"is empty" : "bo\u015f",//No I18n
	"is not empty" : "dolu"//No I18n
}
